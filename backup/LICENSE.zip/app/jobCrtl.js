app.controller('EditJobControler',[
  '$scope','$http','$location','$routeParams',
  function ($scope, $http, $location, $routeParams) {
      var id = $routeParams.id;
      var obj = {};
      $http.get('api/v1/editjob/'+id).then(function(results) {
            //alert(JSON.stringify(results));
            obj.get = results.data;
           $scope.editJobs = obj;
  });

  $scope.doeditJob = function (customer) {
       // alert(JSON.stringify(customer));
       $http.post('api/v1/savejob', {
            customer: customer
        }).then(function (results) {
            //alert(JSON.stringify(results));
            //Data.toast(results);
           // $scope.companies = results;
            if (results.data.status == "success") {
               $scope.messages = 'Job Saved';
               alert("Job Saved");
               $location.path('job');

            }
        });
    };    
     
  }


]);

app.controller('companycrtl',[
  '$scope','$http','$location','$routeParams',
   function($scope, $http) {
    var obj = {};
  $http.get('api/v1/companies').then(function(results) {   
          alert(JSON.stringify(results));        
            obj.get = results.data; 
            $scope.companies = results.data;
  });
$scope.x = 'ABC';
}
]);